package com.example.sqllite;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private DatabaseHandler db;
    private ListView lv;
    private Button btnAdd;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> displayList;
    private ArrayList<SQLlite> contacts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHandler(this);
        lv = findViewById(R.id.lvContacts);
        btnAdd = findViewById(R.id.btnAdd);

        displayList = new ArrayList<>();
        contacts = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, displayList);
        lv.setAdapter(adapter);

        loadData();

        btnAdd.setOnClickListener(v -> showContactDialog(null));

        lv.setOnItemClickListener((parent, view, position, id) -> {
            SQLlite selected = contacts.get(position);
            showContactDialog(selected);
        });

        lv.setOnItemLongClickListener((parent, view, position, id) -> {
            SQLlite sel = contacts.get(position);
            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Xóa contact")
                    .setMessage("Bạn có muốn xóa \"" + sel.getName() + "\" không?")
                    .setPositiveButton("Có", (dialog, which) -> {
                        db.deleteContact(sel);
                        loadData();
                        Toast.makeText(MainActivity.this, "Đã xóa", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("Không", null)
                    .show();
            return true;
        });
    }

    private void loadData() {
        displayList.clear();
        contacts.clear();
        List<SQLlite> list = db.getAllContacts();
        for (SQLlite c : list) {
            contacts.add(c);
            displayList.add(c.getName() + " — " + c.getPhoneNumber());
        }
        adapter.notifyDataSetChanged();
    }

    private void showContactDialog(SQLlite contact) {
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_contact, null);
        EditText etName = dialogView.findViewById(R.id.etName);
        EditText etPhone = dialogView.findViewById(R.id.etPhone);

        boolean isEdit = (contact != null);
        if (isEdit) {
            etName.setText(contact.getName());
            etPhone.setText(contact.getPhoneNumber());
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogView);
        builder.setTitle(isEdit ? "Sửa contact" : "Thêm contact");
        builder.setPositiveButton(isEdit ? "Cập nhật" : "Thêm", (dialog, which) -> {
            String name = etName.getText().toString().trim();
            String phone = etPhone.getText().toString().trim();
            if (name.isEmpty() || phone.isEmpty()) {
                Toast.makeText(MainActivity.this, "Vui lòng nhập đầy đủ", Toast.LENGTH_SHORT).show();
                return;
            }
            if (isEdit) {
                contact.setName(name);
                contact.setPhoneNumber(phone);
                db.updateContact(contact);
                Toast.makeText(MainActivity.this, "Đã cập nhật", Toast.LENGTH_SHORT).show();
            } else {
                db.addContact(new SQLlite(name, phone));
                Toast.makeText(MainActivity.this, "Đã thêm", Toast.LENGTH_SHORT).show();
            }
            loadData();
        });
        builder.setNegativeButton("Hủy", null);
        builder.show();
    }
}
